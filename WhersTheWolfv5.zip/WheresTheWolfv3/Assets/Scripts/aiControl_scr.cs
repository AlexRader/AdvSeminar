﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class aiControl_scr : MonoBehaviour {

	//private GameObject[] npcControl;
	private List<GameObject> aiList;
	public GameObject[] firstMarket;
	//private List<int> maxCapacity;
	//private List<List<GameObject>> locations;

	//public GameObject myPrefab;

	public TypeDay typeDay;
	private bool theTime;

	public GameObject[] findObjects;

	private int[] standardSpawns;

	private int numLists = 0;

	//private int inc = 0;

	private float multiplyFactor = 1.0f;

	public DayState dayState;

	public enum DayState
	{
		Clear
	}

	public enum TypeDay
	{
		Standard
	}



	// Use this for initialization
	void Start () 
	{
		//maxCapacity = new List<int> ();
		//locations = new List<List<GameObject>> ();
		/*
		switch (dayState) 
		{
		case DayState.Clear:
			multiplyFactor = 1.2f;
			break;
		}

		switch (typeDay) 
		{
		case TypeDay.Standard:
			standardSpawns = new int[1] {10};
			break;
		}
		for (int i = 0; i < standardSpawns.Length; ++i) 
		{
			standardSpawns [i] = Mathf.RoundToInt(standardSpawns [i] * multiplyFactor);
		}*/
		setLists ();

		//aiList = new List<GameObject> ();


		//spawnUnits ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}

	void spawnUnits()
	{
		for (int i = 0; i < standardSpawns [numLists]; i++) 
		{
			//aiList[inc] = (GameObject)Instantiate(myPrefab, 
		}
		

	}
	/*
	Vector2 getListPosition(int var)
	{
		
	}
*/
	void setLists()
	{
		//if (firstMarket == null) 
		//{			
			//firstMarket = GameObject.FindGameObjectsWithTag ("firstMarket");
			//setArray("firstMarket");
			//for (int i = 0; i < findObjects.Length; ++i) 
			//{
			firstMarket = GameObject.FindGameObjectsWithTag ("firstMarket");
	//		Debug.Log (firstMarket.Length);
		GameObject.Find ("npc_prefab").SendMessage ("moveTo");
			//}
			//addFactors(firstMarket);

		//}
		

	}

	Vector3 returnNextMove(int var)
	{
		return firstMarket [var].transform.position;
	}
	/*
	void addFactors(List<GameObject> var)
	{
		//locations [numLists] = var;
		locations [numLists] = var;
	}
*/
	void setArray(string var)
	{
		if (findObjects != null)
			Array.Clear (findObjects, 0, findObjects.Length);
		findObjects = GameObject.FindGameObjectsWithTag (var);
	}
	/*
	Vector3 returnListLocation(int var, int var2)
	{
		locations
	}
*/
}
