﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class aiMovement_scr : MonoBehaviour 
{
	private Rigidbody2D myRB;
	private Vector3 endPos;
	private GameObject myObject;
	private int x;
	private int calc;


	private Vector3 velocity;

	//bool happen = false;
	// Use this for initialization
	void Start () 
	{
		myRB = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		move ();


		if (this.transform.position.x - endPos.x < 1f && this.transform.position.x - endPos.x > -1f) 
		{
			if (this.transform.position.y - endPos.y < 1f && this.transform.position.y - endPos.y > -1f) 
			{
				moveTo ();
			}
		}
	
	}


	void moveTo()
	{
			x = GameObject.Find ("aiControl").GetComponent<aiControl_scr> ().firstMarket.Length;
			//Debug.Log (x);
			x -= 1;
			calc = Random.Range (0, x);
//			Debug.Log (calc);
		//	Debug.Log ("here");
		myObject = GameObject.Find ("aiControl").GetComponent<aiControl_scr> ().firstMarket [calc];
		endPos = myObject.transform.position;
	}

	void move()
	{
		velocity = endPos - this.transform.position;
		//velocity /= inc;
		if (velocity.x > 10)
			velocity.x = 10;
		if (velocity.y > 10)
			velocity.y = 10;
		myRB.velocity = velocity;
		//velocity *= Time.deltaTime;
	}

	void death()
	{
		Destroy (this.gameObject);
	}


	void OnTriggerEnter2D(Collider2D coll)
	{
		if (coll.tag == "Player" && coll.GetComponent<TransformAbilities_scr>().attack == true) 
		{
			Debug.Log ("collided");


			death ();
		}
	}
}
