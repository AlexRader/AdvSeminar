﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movement_scr : MonoBehaviour 
{
	private float inc;
	private float maxVel;
	private float curVel;
	private Rigidbody2D myRB;
	private int checkButton;

	private Vector3 moveInput;

	private Vector3 moveVelocity;

	// Use this for initialization
	void Start () 
	{
		myRB = GetComponent<Rigidbody2D> ();
		inc = .2f;
		maxVel = 10;
		curVel = 0;
		checkButton = 0;
	}
	
	// Update is called once per frame
	void Update () 
	{
		float axisX = Input.GetAxis ("Horizontal");
		float axisY = Input.GetAxis ("Vertical");

		moveInput = new Vector3 (axisX, axisY);
		moveVelocity = moveInput * curVel;
		//transform.Translate (new Vector3 (axisX, axisY) * Time.deltaTime * curVel);

		if (Input.GetKey (KeyCode.W)) 
			ModVelocity ();
		if (Input.GetKey (KeyCode.S)) 
			ModVelocity ();
		if (Input.GetKey (KeyCode.A)) 
			ModVelocity ();
		if (Input.GetKey (KeyCode.D)) 
			ModVelocity ();

		myRB.velocity = moveVelocity;
		checkButton = 0;
	}

	void ModVelocity ()
	{
		curVel += inc;
		checkButton += 1;
		if (curVel > maxVel)
			curVel = maxVel;
		if (checkButton > 1)
			curVel *= .95f;
	}
}
