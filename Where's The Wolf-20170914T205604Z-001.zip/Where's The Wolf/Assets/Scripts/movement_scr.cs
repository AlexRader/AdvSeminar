﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movement_scr : MonoBehaviour 
{
	private float inc;
	private float maxVel;
	private float curVel;
	// Use this for initialization
	void Start () 
	{
		inc = .2f;
		maxVel = 10;
		curVel = 0;
	}
	
	// Update is called once per frame
	void Update () 
	{
		float axisX = Input.GetAxis ("Horizontal");
		float axisY = Input.GetAxis ("Vertical");

		transform.Translate (new Vector3 (axisX, axisY) * Time.deltaTime * curVel);

		if (Input.GetKey (KeyCode.W)) 
			ModVelocity ();
		if (Input.GetKey (KeyCode.S)) 
			ModVelocity ();
		if (Input.GetKey (KeyCode.A)) 
			ModVelocity ();
		if (Input.GetKey (KeyCode.D)) 
			ModVelocity ();
	}

	void ModVelocity()
	{
		curVel += inc;
		if (curVel > maxVel)
			curVel = maxVel;
	}
}
